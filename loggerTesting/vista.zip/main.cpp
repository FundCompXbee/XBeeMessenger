#include "aes.h"
#include <stdio.h>
#include <math.h>

typedef unsigned char   u1byte;
typedef unsigned int   u4byte;
#define BLOCK 32
#define SAMPLE 100
u1byte DREF[BLOCK*16],INBLOCK[BLOCK*16],OUTBLOCK[BLOCK*16],TEMP[BLOCK*16],ZERO[BLOCK*16],TEMP2[BLOCK*16],REF[BLOCK*16];
u1byte KEY[32],IV[64],IV3[64];
aes_encrypt_ctx enc_key[1];
aes_decrypt_ctx dec_key[1];

inline void xorblock(u1byte* in, u1byte* out)
{
	for(int i=0;i<16;i++)
		in[i]^=out[i];
}

inline 	void encryptCBC(u1byte in_blk[], u1byte out_blk[],u1byte* IV,aes_encrypt_ctx* key)
		{
			xorblock(in_blk,IV);
	aes_encrypt(in_blk,out_blk,key);
			for(int i=1;i<32;i++)
			{
				xorblock(in_blk+16*i,out_blk+16*(i-1));
			aes_encrypt(in_blk+16*i,out_blk+16*i,key);//,NULL,1);
			}
		}

inline 	void decryptCBC(u1byte in_blk[], u1byte out_blk[],u1byte* IV,aes_decrypt_ctx* key)
		{
		
			
			for(int i=31;i>0;i--)
			{
				
			aes_decrypt(in_blk+16*i,out_blk+16*i,key);
			xorblock(out_blk+16*i,in_blk+16*(i-1));
			}
			aes_decrypt(in_blk,out_blk,key);
			xorblock(out_blk,IV);
		}


inline 	void encryptECB(u1byte in_blk[], u1byte out_blk[],aes_encrypt_ctx* key)
		{
			
			for(int i=0;i<32;i++)
			{
			aes_encrypt(in_blk+16*i,out_blk+16*i,key);
			}
		}

inline 	void decryptECB(u1byte in_blk[], u1byte out_blk[],aes_decrypt_ctx* key)
		{
			
			for(int i=0;i<32;i++)
			{
			aes_decrypt(in_blk+16*i,out_blk+16*i,key);
			}
		}


inline 	void A_dec(u4byte * X, int AC)
	{
		


	for(int i=0;i<AC;i++)
	{
		int N=32*4-1;
		for(int j=0;j<=N;j++){
	
		int cc=j%4,c;
		if(cc==0)
			c=9;
		else if(cc==1 || cc==3)
			c=0;
		else
			c=13;
	if(j<5)
X[j]+=(X[(N+1-j-2)%(N+1)]^_rotl(X[(N+1-j-5)%(N+1)],c));
		else
X[j]+=(X[(j-2)%(N+1)]^_rotl(X[(j-5)%(N+1)],c));		
		}

	}
	}

inline 	void A_enc(u4byte * X,int AC)
	{
	
	for(int i=0;i<AC;i++)
	{
		X[127]-=X[125]^(X[122]);
		X[126]-=X[124]^_rotl(X[121],13);
		X[125]-=X[123]^(X[120]);
		X[124]-=X[122]^_rotl(X[119],9);
		X[123]-=X[121]^(X[118]);
		X[122]-=X[120]^_rotl(X[117],13);
		X[121]-=X[119]^(X[116]);
		X[120]-=X[118]^_rotl(X[115],9);
		X[119]-=X[117]^(X[114]);
		X[118]-=X[116]^_rotl(X[113],13);
		X[117]-=X[115]^(X[112]);
		X[116]-=X[114]^_rotl(X[111],9);
		X[115]-=X[113]^(X[110]);
		X[114]-=X[112]^_rotl(X[109],13);
		X[113]-=X[111]^(X[108]);
		X[112]-=X[110]^_rotl(X[107],9);
		X[111]-=X[109]^(X[106]);
		X[110]-=X[108]^_rotl(X[105],13);
		X[109]-=X[107]^(X[104]);
		X[108]-=X[106]^_rotl(X[103],9);
		X[107]-=X[105]^(X[102]);
		X[106]-=X[104]^_rotl(X[101],13);
		X[105]-=X[103]^(X[100]);
		X[104]-=X[102]^_rotl(X[99],9);
		X[103]-=X[101]^(X[98]);
		X[102]-=X[100]^_rotl(X[97],13);
		X[101]-=X[99]^(X[96]);
		X[100]-=X[98]^_rotl(X[95],9);
		X[99]-=X[97]^(X[94]);
		X[98]-=X[96]^_rotl(X[93],13);
		X[97]-=X[95]^(X[92]);
		X[96]-=X[94]^_rotl(X[91],9);
		X[95]-=X[93]^(X[90]);
		X[94]-=X[92]^_rotl(X[89],13);
		X[93]-=X[91]^(X[88]);
		X[92]-=X[90]^_rotl(X[87],9);
		X[91]-=X[89]^(X[86]);
		X[90]-=X[88]^_rotl(X[85],13);
		X[89]-=X[87]^(X[84]);
		X[88]-=X[86]^_rotl(X[83],9);
		X[87]-=X[85]^(X[82]);
		X[86]-=X[84]^_rotl(X[81],13);
		X[85]-=X[83]^(X[80]);
		X[84]-=X[82]^_rotl(X[79],9);
		X[83]-=X[81]^(X[78]);
		X[82]-=X[80]^_rotl(X[77],13);
		X[81]-=X[79]^(X[76]);
		X[80]-=X[78]^_rotl(X[75],9);
		X[79]-=X[77]^(X[74]);
		X[78]-=X[76]^_rotl(X[73],13);
		X[77]-=X[75]^(X[72]);
		X[76]-=X[74]^_rotl(X[71],9);
		X[75]-=X[73]^(X[70]);
		X[74]-=X[72]^_rotl(X[69],13);
		X[73]-=X[71]^(X[68]);
		X[72]-=X[70]^_rotl(X[67],9);
		X[71]-=X[69]^(X[66]);
		X[70]-=X[68]^_rotl(X[65],13);
		X[69]-=X[67]^(X[64]);
		X[68]-=X[66]^_rotl(X[63],9);
		X[67]-=X[65]^(X[62]);
		X[66]-=X[64]^_rotl(X[61],13);
		X[65]-=X[63]^(X[60]);
		X[64]-=X[62]^_rotl(X[59],9);
		X[63]-=X[61]^(X[58]);
		X[62]-=X[60]^_rotl(X[57],13);
		X[61]-=X[59]^(X[56]);
		X[60]-=X[58]^_rotl(X[55],9);
		X[59]-=X[57]^(X[54]);
		X[58]-=X[56]^_rotl(X[53],13);
		X[57]-=X[55]^(X[52]);
		X[56]-=X[54]^_rotl(X[51],9);
		X[55]-=X[53]^(X[50]);
		X[54]-=X[52]^_rotl(X[49],13);
		X[53]-=X[51]^(X[48]);
		X[52]-=X[50]^_rotl(X[47],9);
		X[51]-=X[49]^(X[46]);
		X[50]-=X[48]^_rotl(X[45],13);
		X[49]-=X[47]^(X[44]);
		X[48]-=X[46]^_rotl(X[43],9);
		X[47]-=X[45]^(X[42]);
		X[46]-=X[44]^_rotl(X[41],13);
		X[45]-=X[43]^(X[40]);
		X[44]-=X[42]^_rotl(X[39],9);
		X[43]-=X[41]^(X[38]);
		X[42]-=X[40]^_rotl(X[37],13);
		X[41]-=X[39]^(X[36]);
		X[40]-=X[38]^_rotl(X[35],9);
		X[39]-=X[37]^(X[34]);
		X[38]-=X[36]^_rotl(X[33],13);
		X[37]-=X[35]^(X[32]);
		X[36]-=X[34]^_rotl(X[31],9);
		X[35]-=X[33]^(X[30]);
		X[34]-=X[32]^_rotl(X[29],13);
		X[33]-=X[31]^(X[28]);
		X[32]-=X[30]^_rotl(X[27],9);
		X[31]-=X[29]^(X[26]);
		X[30]-=X[28]^_rotl(X[25],13);
		X[29]-=X[27]^(X[24]);
		X[28]-=X[26]^_rotl(X[23],9);
		X[27]-=X[25]^(X[22]);
		X[26]-=X[24]^_rotl(X[21],13);
		X[25]-=X[23]^(X[20]);
		X[24]-=X[22]^_rotl(X[19],9);
		X[23]-=X[21]^(X[18]);
		X[22]-=X[20]^_rotl(X[17],13);
		X[21]-=X[19]^(X[16]);
		X[20]-=X[18]^_rotl(X[15],9);
		X[19]-=X[17]^(X[14]);
		X[18]-=X[16]^_rotl(X[13],13);
		X[17]-=X[15]^(X[12]);
		X[16]-=X[14]^_rotl(X[11],9);
		X[15]-=X[13]^(X[10]);
		X[14]-=X[12]^_rotl(X[9],13);
		X[13]-=X[11]^(X[8]);
		X[12]-=X[10]^_rotl(X[7],9);
		X[11]-=X[9]^(X[6]);
		X[10]-=X[8]^_rotl(X[5],13);
		X[9]-=X[7]^(X[4]);
		X[8]-=X[6]^_rotl(X[3],9);
		X[7]-=X[5]^(X[2]);
		X[6]-=X[4]^_rotl(X[1],13);
		X[5]-=X[3]^(X[0]);
		X[4]-=X[122]^_rotl(X[119],9);
		X[3]-=X[123]^(X[120]);
		X[2]-=X[124]^_rotl(X[121],13);
		X[1]-=X[125]^(X[122]);
		X[0]-=X[126]^_rotl(X[123],9);
	}	

}



inline 		void B_dec(u4byte * X, int BC)
	{
		

	for(int i=0;i<BC;i++)
		{
int N=32*4-1;
		for(int j=0;j<=N;j++){
		int cc=j%4,c;
	
	
		if(cc==0 ||cc==2)
			c=0;
		else if(cc==1)
			c=10;
		else
			c=25;
	
X[j]+=(X[(j+2)%(N+1)]^_rotl(X[(j+5)%(N+1)],c));		
		}

}
	}


inline 	void B_enc(u4byte * X,int BC)
	{
		for(int i=0;i<BC;i++)
		{
			X[127]-=X[1]^_rotl(X[4],25);
			X[126]-=X[0]^(X[3]);
			X[125]-=X[127]^_rotl(X[2],10);
			X[124]-=X[126]^(X[1]);
			X[123]-=X[125]^_rotl(X[0],25);
			X[122]-=X[124]^(X[127]);
			X[121]-=X[123]^_rotl(X[126],10);
			X[120]-=X[122]^(X[125]);
			X[119]-=X[121]^_rotl(X[124],25);
			X[118]-=X[120]^(X[123]);
			X[117]-=X[119]^_rotl(X[122],10);
			X[116]-=X[118]^(X[121]);
			X[115]-=X[117]^_rotl(X[120],25);
			X[114]-=X[116]^(X[119]);
			X[113]-=X[115]^_rotl(X[118],10);
			X[112]-=X[114]^(X[117]);
			X[111]-=X[113]^_rotl(X[116],25);
			X[110]-=X[112]^(X[115]);
			X[109]-=X[111]^_rotl(X[114],10);
			X[108]-=X[110]^(X[113]);
			X[107]-=X[109]^_rotl(X[112],25);
			X[106]-=X[108]^(X[111]);
			X[105]-=X[107]^_rotl(X[110],10);
			X[104]-=X[106]^(X[109]);
			X[103]-=X[105]^_rotl(X[108],25);
			X[102]-=X[104]^(X[107]);
			X[101]-=X[103]^_rotl(X[106],10);
			X[100]-=X[102]^(X[105]);
			X[99]-=X[101]^_rotl(X[104],25);
			X[98]-=X[100]^(X[103]);
			X[97]-=X[99]^_rotl(X[102],10);
			X[96]-=X[98]^(X[101]);
			X[95]-=X[97]^_rotl(X[100],25);
			X[94]-=X[96]^(X[99]);
			X[93]-=X[95]^_rotl(X[98],10);
			X[92]-=X[94]^(X[97]);
			X[91]-=X[93]^_rotl(X[96],25);
			X[90]-=X[92]^(X[95]);
			X[89]-=X[91]^_rotl(X[94],10);
			X[88]-=X[90]^(X[93]);
			X[87]-=X[89]^_rotl(X[92],25);
			X[86]-=X[88]^(X[91]);
			X[85]-=X[87]^_rotl(X[90],10);
			X[84]-=X[86]^(X[89]);
			X[83]-=X[85]^_rotl(X[88],25);
			X[82]-=X[84]^(X[87]);
			X[81]-=X[83]^_rotl(X[86],10);
			X[80]-=X[82]^(X[85]);
			X[79]-=X[81]^_rotl(X[84],25);
			X[78]-=X[80]^(X[83]);
			X[77]-=X[79]^_rotl(X[82],10);
			X[76]-=X[78]^(X[81]);
			X[75]-=X[77]^_rotl(X[80],25);
			X[74]-=X[76]^(X[79]);
			X[73]-=X[75]^_rotl(X[78],10);
			X[72]-=X[74]^(X[77]);
			X[71]-=X[73]^_rotl(X[76],25);
			X[70]-=X[72]^(X[75]);
			X[69]-=X[71]^_rotl(X[74],10);
			X[68]-=X[70]^(X[73]);
			X[67]-=X[69]^_rotl(X[72],25);
			X[66]-=X[68]^(X[71]);
			X[65]-=X[67]^_rotl(X[70],10);
			X[64]-=X[66]^(X[69]);
			X[63]-=X[65]^_rotl(X[68],25);
			X[62]-=X[64]^(X[67]);
			X[61]-=X[63]^_rotl(X[66],10);
			X[60]-=X[62]^(X[65]);
			X[59]-=X[61]^_rotl(X[64],25);
			X[58]-=X[60]^(X[63]);
			X[57]-=X[59]^_rotl(X[62],10);
			X[56]-=X[58]^(X[61]);
			X[55]-=X[57]^_rotl(X[60],25);
			X[54]-=X[56]^(X[59]);
			X[53]-=X[55]^_rotl(X[58],10);
			X[52]-=X[54]^(X[57]);
			X[51]-=X[53]^_rotl(X[56],25);
			X[50]-=X[52]^(X[55]);
			X[49]-=X[51]^_rotl(X[54],10);
			X[48]-=X[50]^(X[53]);
			X[47]-=X[49]^_rotl(X[52],25);
			X[46]-=X[48]^(X[51]);
			X[45]-=X[47]^_rotl(X[50],10);
			X[44]-=X[46]^(X[49]);
			X[43]-=X[45]^_rotl(X[48],25);
			X[42]-=X[44]^(X[47]);
			X[41]-=X[43]^_rotl(X[46],10);
			X[40]-=X[42]^(X[45]);
			X[39]-=X[41]^_rotl(X[44],25);
			X[38]-=X[40]^(X[43]);
			X[37]-=X[39]^_rotl(X[42],10);
			X[36]-=X[38]^(X[41]);
			X[35]-=X[37]^_rotl(X[40],25);
			X[34]-=X[36]^(X[39]);
			X[33]-=X[35]^_rotl(X[38],10);
			X[32]-=X[34]^(X[37]);
			X[31]-=X[33]^_rotl(X[36],25);
			X[30]-=X[32]^(X[35]);
			X[29]-=X[31]^_rotl(X[34],10);
			X[28]-=X[30]^(X[33]);
			X[27]-=X[29]^_rotl(X[32],25);
			X[26]-=X[28]^(X[31]);
			X[25]-=X[27]^_rotl(X[30],10);
			X[24]-=X[26]^(X[29]);
			X[23]-=X[25]^_rotl(X[28],25);
			X[22]-=X[24]^(X[27]);
			X[21]-=X[23]^_rotl(X[26],10);
			X[20]-=X[22]^(X[25]);
			X[19]-=X[21]^_rotl(X[24],25);
			X[18]-=X[20]^(X[23]);
			X[17]-=X[19]^_rotl(X[22],10);
			X[16]-=X[18]^(X[21]);
			X[15]-=X[17]^_rotl(X[20],25);
			X[14]-=X[16]^(X[19]);
			X[13]-=X[15]^_rotl(X[18],10);
			X[12]-=X[14]^(X[17]);
			X[11]-=X[13]^_rotl(X[16],25);
			X[10]-=X[12]^(X[15]);
			X[9]-=X[11]^_rotl(X[14],10);
			X[8]-=X[10]^(X[13]);
			X[7]-=X[9]^_rotl(X[12],25);
			X[6]-=X[8]^(X[11]);
			X[5]-=X[7]^_rotl(X[10],10);
			X[4]-=X[6]^(X[9]);
			X[3]-=X[5]^_rotl(X[8],25);
			X[2]-=X[4]^(X[7]);
			X[1]-=X[3]^_rotl(X[6],10);
			X[0]-=X[2]^(X[5]);
}
}


inline 	void encryptELF(u1byte in_blk[], u1byte out_blk[],u1byte* IV,u1byte*IV2, int AC,int BC,aes_encrypt_ctx* key)
	{
		
	for(int i=0;i<32;i++)
		xorblock(in_blk+16*i,IV);

	u4byte* X=(u4byte*)in_blk;

	unsigned __int64* XX=(unsigned __int64*)in_blk;
	A_enc(X,AC);
	B_enc(X,BC);

	
	encryptCBC(in_blk,out_blk,IV2,key);


	}

inline 		void decryptELF(u1byte in_blk[], u1byte out_blk[],u1byte* IV,u1byte*IV2,int AC,int BC,aes_decrypt_ctx* key)
	{
	

	
	
	decryptCBC(in_blk,out_blk,IV2,key);
	u4byte* X=(u4byte*)out_blk;
	unsigned __int64* XX=(	unsigned __int64*)out_blk;
	

		B_dec(X,BC);
		A_dec(X,AC);


for(int i=0;i<32;i++)
		xorblock(out_blk+16*i,IV);




	}
inline 	void myencryptELF(u1byte in_blk[], u1byte out_blk[],u1byte* IV,int AC,int BC,aes_encrypt_ctx* key)
	{
//	exIV(IV,EXIV);
	u1byte II[16];
		for(int j=0;j<16;j++)
			II[j]=IV[j];
for(int i=0;i<32;i++)
{
	
	xorblock(in_blk+16*i,II);
	II[15]++;
}

	u4byte* X=(u4byte*)in_blk;

	unsigned __int64* XX=(unsigned __int64*)in_blk;
	A_enc(X,AC);
	B_enc(X,BC);

	
	encryptECB(in_blk,out_blk,key);


	}

inline 		void mydecryptELF(u1byte in_blk[], u1byte out_blk[],u1byte* IV,int AC,int BC,aes_decrypt_ctx* key)
	{
	

	
	
	decryptECB(in_blk,out_blk,key);
	u4byte* X=(u4byte*)out_blk;
	unsigned __int64* XX=(	unsigned __int64*)out_blk;

		B_dec(X,BC);
		A_dec(X,AC);


		u1byte II[16];
		for(int j=0;j<16;j++)
			II[j]=IV[j];
for(int i=0;i<32;i++)
{
	
	xorblock(out_blk+16*i,II);
	II[15]++;
}



	}

inline	void Ready()
	{

			for(int i=0;i<32*16;i++)
			INBLOCK[i]=OUTBLOCK[i]=ZERO[i]=0;
		for(i=0;i<32;i++)
			KEY[i]=i;
		for(i=0;i<64;i++)
		{
		IV[i]=IV3[i]=2*i;
		
		}
	
aes_decrypt_key256(KEY,dec_key);
aes_encrypt_key256(KEY,enc_key);
	}

inline	void Ready2()
	{

			for(int i=0;i<32*16;i++)
			INBLOCK[i]=OUTBLOCK[i]=ZERO[i]=255;
		for(i=0;i<32;i++)
			KEY[i]=i;
		for(i=0;i<64;i++)
		{	
		IV[i]=IV3[i]=2*i;
		
		}
	
	}

inline	void Ready3()
	{
		
			for(int i=0;i<32*16;i++)
			INBLOCK[i]=OUTBLOCK[i]=ZERO[i]=rand()%256;
		for(i=0;i<32;i++)
			KEY[i]=i;
		for(i=0;i<64;i++)
		{	
		IV[i]=IV3[i]=2*i;
		}
	
	}

	void init(double* X)
	{
	for(int i=0;i<BLOCK*128;i++)
	X[i]=0;
	
	}

inline	void ConvertToBits2(u1byte*In,u1byte*out,int Len)
{
int x=0;
	for (int i=0;i<Len;i++)
{
u1byte C=In[i];
for(int j=7;j>=0;j--)
{
out[x]=C%2;
C=C/2;
x++;

}

}

}

	inline void ChangeBit(const u1byte * In,u1byte* out,int index,int Len)
{
	for(int i=0;i<Len;i++)
		out[i]=In[i];
int byteindex=floor(index/8);
int offset=index%8;
u1byte Mask[8]={1,2,4,8,16,32,64,128};
u1byte Mask2[8]={254,253,251,255-8,255-16,255-32,255-64,255-128};

u1byte UsedMask=Mask[offset];
u1byte ReqByte=In[byteindex];
u1byte Result=ReqByte&UsedMask;
u1byte UsedMask2;

if(Result==0)
{
UsedMask2=Mask[offset];
out[byteindex]|=UsedMask2;
}
else
{
UsedMask2=Mask2[offset];
out[byteindex]&=UsedMask2;

}

}

	inline	void AnalF(double* in, double * out)
	{
	double Min=in[0];

	double Max=in[0];
	double Sum=in[0],AVG;
	for(int i=1;i<32*128;i++)
	{
	if(in[i]<Min)
	{Min=in[i];
	

	}if(in[i]>Max)Max=in[i];
	Sum+=in[i];
	}
	AVG=Sum/(32*128);
	out[0]=Min;
	out[1]=Max;
	out[2]=Sum;
	out[3]=AVG;
	Sum=0;
for( i=0;i<32*128;i++)
	{
Sum+=(in[i]-AVG)*(in[i]-AVG);
}
Sum=Sum/(32*128);
Sum=sqrt(Sum);
out[4]=Sum;

	}

inline void xorsector(u1byte* in, u1byte* out)
{
	for(int i=0;i<16*32;i++)
		in[i]^=out[i];
}

inline void AnalM(double in[BLOCK*128][5], double  out[5][5])
	{
double temp[BLOCK*128];
	for(int i=0;i<5;i++)
	{
	for(int j=0;j<32*128;j++)
		temp[j]=in[j][i];
		AnalF(temp,out[i]);
	}
	}

inline 	void AVL(int alg,int AC,int BC)
	{
	
double Matrix[100][5];
	double Matrix2[100][5];

	double F[BLOCK*128];
double F2[BLOCK*128];


	u1byte B[BLOCK*128];
	
	double Summary[5][5]={0};
	double Summary2[5][5]={0};
	char buf[80];
	char buf2[80];


if(alg==1)
{
sprintf(buf,"c:\\test\\Test3_AES_CBC_%d_%d.txt",AC,BC);
sprintf(buf2,"c:\\test\\Test4_AES_CBC_%d_%d.txt",AC,BC);
}
else
{
sprintf(buf,"c:\\test\\Test3_AES_ECB_%d_%d.txt",AC,BC);
sprintf(buf2,"c:\\test\\Test4_AES_ECB_%d_%d.txt",AC,BC);
}

printf("%s\n",buf);
	FILE *f=fopen(buf,"w");
	FILE *f2=fopen(buf2,"w");

		

	{

	{

	srand(0);
	Summary2[0][0]=1000000 ; Summary[0][0]=1000000;
		Summary2[1][1]=0 ; Summary[1][1]=0;
for(int j=0;j<SAMPLE;j++)

{
if(j==0)
		Ready();
	else
		if(j==1)
			Ready2();
		else
Ready3();

		if(alg==1)
		{
		encryptELF(INBLOCK,REF,IV,IV+16,AC,BC,enc_key);
		decryptELF(OUTBLOCK,DREF,IV,IV+16,AC,BC,dec_key);
		}
		else
		{
		myencryptELF(INBLOCK,REF,IV,AC,BC,enc_key);
		mydecryptELF(OUTBLOCK,DREF,IV,AC,BC,dec_key);
		
		}
	init(F);
	init(F2);
{

for(int i=0;i<32*16*8;i++)

	{


{
	ChangeBit(INBLOCK,TEMP,i,32*16);
	
	if(alg==1)
		{
		encryptELF(TEMP,OUTBLOCK,IV,IV+16,AC,BC,enc_key);
	
		}
		else
		{
		myencryptELF(TEMP,OUTBLOCK,IV,AC,BC,enc_key);
		}
xorsector(OUTBLOCK,DREF);
ConvertToBits2(OUTBLOCK,B,32*16);
for(int k=0;k<32*16*8;k++)
F[k]+=B[k];


}
{
if(j==0)
		Ready();
	else
		if(j==1)
			Ready2();
		else
Ready3();

		ChangeBit(INBLOCK,TEMP,i,32*16);

if(alg==1)
		{
		decryptELF(TEMP,OUTBLOCK,IV,IV+16,AC,BC,dec_key);
	
		}
		else
		{
		mydecryptELF(TEMP,OUTBLOCK,IV,AC,BC,dec_key);
		}
	xorsector(OUTBLOCK,DREF);
	ConvertToBits2(OUTBLOCK,B,32*16);


for(int k=0;k<32*16*8;k++)
F2[k]+=B[k];
}
	}
AnalF(F,Matrix[j]);
AnalF(F2,Matrix2[j]);

if(Matrix[j][0]==0)
printf("FRW %d\n",j);
if(Matrix2[j][0]==0)
printf("BCK %d\n",j);

if(Matrix[j][0]<Summary[0][0])
Summary[0][0]=Matrix[j][0];
if(Matrix[j][1]>Summary[1][1])
Summary[1][1]=Matrix[j][1];
Summary[3][3]+=Matrix[j][3];
Summary[4][3]+=Matrix[j][4];

if(Matrix2[j][0]<Summary2[0][0])
Summary2[0][0]=Matrix2[j][0];
if(Matrix2[j][1]>Summary2[1][1])
Summary2[1][1]=Matrix2[j][1];
Summary2[3][3]+=Matrix2[j][3];
Summary2[4][3]+=Matrix2[j][4];


}
}

Summary2[3][3]/=SAMPLE;
Summary2[4][3]/=SAMPLE;
Summary[3][3]/=SAMPLE;
Summary[4][3]/=SAMPLE;


printf("%f\t",Summary[0][0]);
printf("%f\t",Summary[1][1]);

printf("%f\t",Summary2[0][0]);
printf("%f\t",Summary2[1][1]);




fprintf(f,"%d\t",AC);
fprintf(f,"%d\t",BC);


fprintf(f,"%f\t",Summary[0][0]);
fprintf(f,"%f\t",Summary[1][1]);
fprintf(f,"%f\t",Summary[3][3]);
fprintf(f,"%f\t",Summary[4][3]);



fprintf(f2,"%d\t",AC);
fprintf(f2,"%d\t",BC);


fprintf(f2,"%f\t",Summary2[0][0]);
fprintf(f2,"%f\t",Summary2[1][1]);
fprintf(f2,"%f\t",Summary2[3][3]);
fprintf(f2,"%f\t",Summary2[4][3]);







		}	}
fclose(f);

fclose(f2);
		

}

inline 	void Stat(int alg,int AC,int BC)
	{
		

double Matrix[BLOCK*128][5];
	double Matrix2[BLOCK*128][5];

	double F[BLOCK*128];
double F2[BLOCK*128];


	u1byte B[BLOCK*128];
	
	double Summary[5][5];
	double Summary2[5][5];
	char buf[80];
	char buf2[80];

	

if(alg==1)
{
sprintf(buf,"c:\\test\\Test1_AES_CBC_%d_%d.txt",AC,BC);
sprintf(buf2,"c:\\test\\Test2_AES_CBC_%d_%d.txt",AC,BC);
}
else
{
sprintf(buf,"c:\\test\\Test1_AES_ECB_%d_%d.txt",AC,BC);
sprintf(buf2,"c:\\test\\Test2_AES_ECB_%d_%d.txt",AC,BC);
}printf("%s\n",buf);

	FILE *f=fopen(buf,"w");
	FILE *f2=fopen(buf2,"w");
	

	{


		


	{
	
	srand(0);
	Summary2[0][0]=0 ; Summary[0][0]=0;
for(int i=0;i<32*16*8;i++)
{

	init(F);
	init(F2);
{

for(int j=0;j<SAMPLE;j++)
	{
if(Summary[0][0]==0)
{if(j==0)
		Ready();
	else
		if(j==1)
			Ready2();
		else
Ready3();

if(alg==1)
		{
		encryptELF(INBLOCK,OUTBLOCK,IV,IV+16,AC,BC,enc_key);
	
		}
		else
		{
		myencryptELF(INBLOCK,OUTBLOCK,IV,AC,BC,enc_key);
		}
	
ChangeBit(OUTBLOCK,TEMP,i,32*16);



if(alg==1)
		{
		decryptELF(TEMP,OUTBLOCK,IV,IV+16,AC,BC,dec_key);
	
		}
		else
		{
		mydecryptELF(TEMP,OUTBLOCK,IV,AC,BC,dec_key);
		}
xorsector(OUTBLOCK,ZERO);
ConvertToBits2(OUTBLOCK,B,32*16);
for(int k=0;k<32*16*8;k++)
F[k]+=B[k];
//--------------------------------------------

}
if(Summary2[0][0]==0)
{
if(j==0)
		Ready();
	else
		if(j==1)
			Ready2();
		else
Ready3();

	
if(alg==1)
		{
		encryptELF(INBLOCK,OUTBLOCK,IV,IV+16,AC,BC,enc_key);
	
		}
		else
		{
		myencryptELF(INBLOCK,OUTBLOCK,IV,AC,BC,enc_key);
		}		
ChangeBit(INBLOCK,TEMP,i,32*16);


if(alg==1)
		{
		encryptELF(TEMP,TEMP2,IV,IV+16,AC,BC,enc_key);
	
		}
		else
		{
		myencryptELF(TEMP,TEMP2,IV,AC,BC,enc_key);
		}
xorsector(OUTBLOCK,TEMP2);
ConvertToBits2(OUTBLOCK,B,32*16);
for(int k=0;k<32*16*8;k++)
F2[k]+=B[k];
}
	}
AnalF(F,Matrix[i]);
AnalF(F2,Matrix2[i]);

}
}
AnalM(Matrix,Summary);
AnalM(Matrix2,Summary2);


printf("%d\t",AC);
printf("%d\t",BC);

printf("\n");

printf("%f\t",Summary[0][0]);
printf("%f\t",Summary[1][1]);

printf("\n%f\t",Summary2[0][0]);
printf("%f\t",Summary2[1][1]);


fprintf(f,"%d\t",AC);

fprintf(f,"%d\t",BC);


fprintf(f,"%f\t",Summary[0][0]);
fprintf(f,"%f\t",Summary[1][1]);
fprintf(f,"%f\t",Summary[3][3]);
fprintf(f,"%f\t",Summary[4][3]);



fprintf(f2,"%d\t",AC);
fprintf(f2,"%d\t",BC);


fprintf(f2,"%f\t",Summary2[0][0]);
fprintf(f2,"%f\t",Summary2[1][1]);
fprintf(f2,"%f\t",Summary2[3][3]);
fprintf(f2,"%f\t",Summary2[4][3]);






		}	}
fclose(f);

fclose(f2);
		

}
void main()
{
	printf("The AES-CBC + Elephant diffuser cipher is patent to Microsoft, the proposed AES-ECB + Elephant diffuser follows this patent too, they are presented here only for demonstration purpose !!!");

	// Apply Test1 and test2 to
	//AES-CBC + Elephant diffuser, with original then proposed values of AC and BC
	Stat(1,5,3);
	Stat(1,2,1);
	//AES-ECB + Elephant diffuser, with original then proposed values of AC and BC
	Stat(2,5,3);
	Stat(2,2,2);

// Apply Test3 and test4 to
//AES-CBC + Elephant diffuser, with original then proposed values of AC and BC
	AVL(1,5,3);
	AVL(1,2,1);
//AES-ECB + Elephant diffuser, with original then proposed values of AC and BC
	AVL(2,5,3);
	AVL(2,2,2);

/* 
To use AES-CBC + Elephant diffuser
call encryptELF for encryption and decryptELF for decryption

To use AES-ECB + Elephant diffuser
call myencryptELF for encryption and mydecryptELF for decryption

NOTE :
Don't forget to setup the key before encrypting or decryptiong using for example:
aes_decrypt_key256
aes_encrypt_key256

  for more detail about the AES implmetation and its optimization, please take a look at : http://fp.gladman.plus.com/AES/

*/


}